import { createClient } from "@/lib/supabase/server";
import type { Category, Product } from "@/lib/types";

const PRODUCT_SELECT = "*, categories(name, slug)";

export async function getCategories(): Promise<Category[]> {
  try {
    const supabase = await createClient();
    const { data } = await supabase.from("categories").select("*").order("name");
    return (data ?? []) as Category[];
  } catch {
    return [];
  }
}

export async function getFeaturedProducts(limit = 8): Promise<Product[]> {
  try {
    const supabase = await createClient();
    const { data } = await supabase
      .from("products")
      .select(PRODUCT_SELECT)
      .eq("featured", true)
      .order("created_at", { ascending: false })
      .limit(limit);
    return (data ?? []) as unknown as Product[];
  } catch {
    return [];
  }
}

export async function getProducts(opts: {
  q?: string;
  category?: string;
  sort?: string;
}): Promise<Product[]> {
  try {
    const supabase = await createClient();
    let query = supabase.from("products").select(PRODUCT_SELECT);

    if (opts.category) {
      const { data: cat } = await supabase
        .from("categories")
        .select("id")
        .eq("slug", opts.category)
        .maybeSingle();
      if (!cat) return [];
      query = query.eq("category_id", cat.id);
    }

    if (opts.q) {
      // Strip characters that have meaning in PostgREST filter syntax.
      const safe = opts.q.replace(/[%,()*]/g, " ").trim();
      if (safe) query = query.or(`name.ilike.%${safe}%,description.ilike.%${safe}%`);
    }

    switch (opts.sort) {
      case "price_asc":
        query = query.order("price", { ascending: true });
        break;
      case "price_desc":
        query = query.order("price", { ascending: false });
        break;
      case "name":
        query = query.order("name", { ascending: true });
        break;
      default:
        query = query.order("created_at", { ascending: false });
    }

    const { data } = await query;
    return (data ?? []) as unknown as Product[];
  } catch {
    return [];
  }
}

export async function getProductBySlug(slug: string): Promise<Product | null> {
  try {
    const supabase = await createClient();
    const { data } = await supabase
      .from("products")
      .select(PRODUCT_SELECT)
      .eq("slug", slug)
      .maybeSingle();
    return (data as unknown as Product) ?? null;
  } catch {
    return null;
  }
}
