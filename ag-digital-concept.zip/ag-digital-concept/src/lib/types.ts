export type Category = {
  id: string;
  name: string;
  slug: string;
};

export type Product = {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  price: number;
  stock: number;
  image_url: string | null;
  featured: boolean;
  category_id: string | null;
  categories?: { name: string; slug: string } | null;
};

export type CartLine = {
  product_id: string;
  name: string;
  price: number;
  image_url: string | null;
  quantity: number;
};

export type Order = {
  id: string;
  created_at: string;
  status: string;
  total: number;
  payment_method: string;
  full_name: string;
  phone: string;
  address: string;
  city: string;
};
