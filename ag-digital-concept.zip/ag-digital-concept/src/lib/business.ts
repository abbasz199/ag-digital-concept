export const BUSINESS = {
  name: "AG Digital Concept",
  tagline: "Quality computer accessories you can trust",
  email: "garbadeen199@gmail.com",
  phone: "08162456504",
  phoneIntl: "+2348162456504",
  address: "First Gate Dadin Kowa, Jos South, Plateau State, Nigeria",
  mapsUrl:
    "https://www.google.com/maps/search/?api=1&query=" +
    encodeURIComponent("First Gate Dadin Kowa, Jos South, Plateau State, Nigeria"),
  currency: "₦",
};

export function formatPrice(n: number) {
  return `${BUSINESS.currency}${Number(n).toLocaleString("en-NG")}`;
}
