import type { Category, Product } from "@/lib/types";

export default function ProductForm({
  action,
  categories,
  product,
  submitLabel,
}: {
  action: (formData: FormData) => void | Promise<void>;
  categories: Category[];
  product?: Product;
  submitLabel: string;
}) {
  return (
    <form action={action} className="grid gap-4 sm:grid-cols-2">
      <label className="block sm:col-span-2">
        <span className="mb-1 block text-sm font-medium">Product name *</span>
        <input name="name" required defaultValue={product?.name} className="input" />
      </label>

      <label className="block">
        <span className="mb-1 block text-sm font-medium">Price (₦) *</span>
        <input
          name="price"
          type="number"
          min={0}
          step="0.01"
          required
          defaultValue={product?.price}
          className="input"
        />
      </label>

      <label className="block">
        <span className="mb-1 block text-sm font-medium">Stock *</span>
        <input
          name="stock"
          type="number"
          min={0}
          step={1}
          required
          defaultValue={product?.stock ?? 0}
          className="input"
        />
      </label>

      <label className="block">
        <span className="mb-1 block text-sm font-medium">Category</span>
        <select name="category_id" defaultValue={product?.category_id ?? ""} className="input">
          <option value="">None</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </label>

      <label className="block">
        <span className="mb-1 block text-sm font-medium">
          Image {product?.image_url ? "(upload to replace)" : ""}
        </span>
        <input name="image" type="file" accept="image/*" className="input" />
      </label>

      <label className="block sm:col-span-2">
        <span className="mb-1 block text-sm font-medium">Description</span>
        <textarea
          name="description"
          rows={3}
          defaultValue={product?.description ?? ""}
          className="input"
        />
      </label>

      <label className="flex items-center gap-2 sm:col-span-2">
        <input name="featured" type="checkbox" defaultChecked={product?.featured} />
        <span className="text-sm font-medium">Show on the home page as featured</span>
      </label>

      <div className="sm:col-span-2">
        <button className="btn">{submitLabel}</button>
      </div>
    </form>
  );
}
