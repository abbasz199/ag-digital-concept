import Link from "next/link";
import type { Product } from "@/lib/types";
import { formatPrice } from "@/lib/business";
import AddToCartButton from "./AddToCartButton";

export function ProductImage({ product, className = "" }: { product: Product; className?: string }) {
  return product.image_url ? (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={product.image_url}
      alt={product.name}
      className={`h-full w-full object-cover ${className}`}
      loading="lazy"
    />
  ) : (
    <div
      className={`flex h-full w-full items-center justify-center bg-brand-100 text-5xl ${className}`}
      role="img"
      aria-label={product.name}
    >
      🖱️
    </div>
  );
}

export default function ProductCard({ product }: { product: Product }) {
  const inStock = product.stock > 0;
  return (
    <div className="card flex flex-col overflow-hidden">
      <Link href={`/products/${product.slug}`} className="block aspect-square overflow-hidden">
        <ProductImage product={product} />
      </Link>
      <div className="flex flex-1 flex-col p-4">
        {product.categories?.name && (
          <span className="text-xs font-medium uppercase tracking-wide text-brand-700">
            {product.categories.name}
          </span>
        )}
        <Link href={`/products/${product.slug}`} className="mt-1 font-semibold hover:text-brand-700">
          {product.name}
        </Link>
        <div className="mt-2 flex items-center justify-between">
          <span className="text-lg font-bold text-brand-800">{formatPrice(product.price)}</span>
          <span className={`text-xs font-medium ${inStock ? "text-brand-700" : "text-red-600"}`}>
            {inStock ? "In stock" : "Sold out"}
          </span>
        </div>
        <AddToCartButton product={product} disabled={!inStock} className="mt-4 w-full" />
      </div>
    </div>
  );
}
