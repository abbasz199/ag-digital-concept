"use client";

import { useState } from "react";
import { useCart } from "./CartProvider";

export default function AddToCartButton({
  product,
  disabled = false,
  className = "",
}: {
  product: { id: string; name: string; price: number; image_url: string | null };
  disabled?: boolean;
  className?: string;
}) {
  const { add } = useCart();
  const [added, setAdded] = useState(false);

  return (
    <button
      type="button"
      className={`btn ${className}`}
      disabled={disabled}
      onClick={() => {
        add({
          product_id: product.id,
          name: product.name,
          price: Number(product.price),
          image_url: product.image_url,
        });
        setAdded(true);
        setTimeout(() => setAdded(false), 1500);
      }}
    >
      {disabled ? "Out of stock" : added ? "Added ✓" : "Add to cart"}
    </button>
  );
}
