"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { createClient } from "@/lib/supabase/client";
import type { CartLine } from "@/lib/types";

type CartContextValue = {
  lines: CartLine[];
  count: number;
  subtotal: number;
  add: (line: Omit<CartLine, "quantity">, qty?: number) => void;
  setQuantity: (productId: string, qty: number) => void;
  remove: (productId: string) => void;
  clear: () => void;
};

const CartContext = createContext<CartContextValue | null>(null);
const STORAGE_KEY = "agdc_cart_v1";

export function CartProvider({ children }: { children: ReactNode }) {
  const supabase = useMemo(() => createClient(), []);
  const [lines, setLines] = useState<CartLine[]>([]);
  const linesRef = useRef<CartLine[]>([]);
  const userIdRef = useRef<string | null>(null);

  const commit = useCallback((next: CartLine[]) => {
    linesRef.current = next;
    setLines(next);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      /* storage unavailable */
    }
  }, []);

  // Load guest cart from local storage, then sync with Supabase when logged in.
  useEffect(() => {
    let cancelled = false;

    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        linesRef.current = JSON.parse(raw) as CartLine[];
        setLines(linesRef.current);
      }
    } catch {
      /* ignore corrupt storage */
    }

    async function sync(uid: string | null) {
      userIdRef.current = uid;
      if (!uid) return;
      try {
        const local = linesRef.current;
        const { data } = await supabase
          .from("cart_items")
          .select("quantity, products(id, name, price, image_url)")
          .eq("user_id", uid);

        const merged = new Map<string, CartLine>();
        for (const row of (data ?? []) as any[]) {
          const p = Array.isArray(row.products) ? row.products[0] : row.products;
          if (!p) continue;
          merged.set(p.id, {
            product_id: p.id,
            name: p.name,
            price: Number(p.price),
            image_url: p.image_url,
            quantity: row.quantity,
          });
        }
        for (const l of local) {
          const existing = merged.get(l.product_id);
          if (existing) existing.quantity = Math.max(existing.quantity, l.quantity);
          else merged.set(l.product_id, l);
        }
        const result = Array.from(merged.values());
        if (cancelled) return;
        commit(result);
        if (result.length) {
          await supabase.from("cart_items").upsert(
            result.map((l) => ({
              user_id: uid,
              product_id: l.product_id,
              quantity: l.quantity,
            })),
            { onConflict: "user_id,product_id" }
          );
        }
      } catch {
        /* keep local cart if Supabase is unreachable */
      }
    }

    supabase.auth
      .getUser()
      .then(({ data }) => sync(data.user?.id ?? null))
      .catch(() => {});

    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "SIGNED_OUT") {
        userIdRef.current = null;
        commit([]);
        return;
      }
      if (event === "SIGNED_IN") sync(session?.user.id ?? null);
    });

    return () => {
      cancelled = true;
      sub.subscription.unsubscribe();
    };
  }, [supabase, commit]);

  const persist = useCallback(
    (task: (uid: string) => PromiseLike<unknown>) => {
      const uid = userIdRef.current;
      if (!uid) return;
      Promise.resolve(task(uid)).catch(() => {});
    },
    []
  );

  const add = useCallback<CartContextValue["add"]>(
    (line, qty = 1) => {
      const current = linesRef.current;
      const existing = current.find((l) => l.product_id === line.product_id);
      const next = existing
        ? current.map((l) =>
            l.product_id === line.product_id ? { ...l, quantity: l.quantity + qty } : l
          )
        : [...current, { ...line, quantity: qty }];
      commit(next);
      const newQty = next.find((l) => l.product_id === line.product_id)!.quantity;
      persist((uid) =>
        supabase
          .from("cart_items")
          .upsert(
            { user_id: uid, product_id: line.product_id, quantity: newQty },
            { onConflict: "user_id,product_id" }
          )
      );
    },
    [commit, persist, supabase]
  );

  const remove = useCallback<CartContextValue["remove"]>(
    (productId) => {
      commit(linesRef.current.filter((l) => l.product_id !== productId));
      persist((uid) =>
        supabase.from("cart_items").delete().eq("user_id", uid).eq("product_id", productId)
      );
    },
    [commit, persist, supabase]
  );

  const setQuantity = useCallback<CartContextValue["setQuantity"]>(
    (productId, qty) => {
      if (qty <= 0) return remove(productId);
      commit(
        linesRef.current.map((l) => (l.product_id === productId ? { ...l, quantity: qty } : l))
      );
      persist((uid) =>
        supabase
          .from("cart_items")
          .upsert(
            { user_id: uid, product_id: productId, quantity: qty },
            { onConflict: "user_id,product_id" }
          )
      );
    },
    [commit, persist, remove, supabase]
  );

  const clear = useCallback(() => {
    commit([]);
    persist((uid) => supabase.from("cart_items").delete().eq("user_id", uid));
  }, [commit, persist, supabase]);

  const value = useMemo<CartContextValue>(
    () => ({
      lines,
      count: lines.reduce((n, l) => n + l.quantity, 0),
      subtotal: lines.reduce((n, l) => n + l.price * l.quantity, 0),
      add,
      setQuantity,
      remove,
      clear,
    }),
    [lines, add, setQuantity, remove, clear]
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used inside <CartProvider>");
  return ctx;
}
