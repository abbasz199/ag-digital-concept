import Link from "next/link";
import { BUSINESS } from "@/lib/business";
import { Brand } from "./Navbar";

export default function Footer() {
  return (
    <footer className="mt-16 bg-brand-900 text-brand-100">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 md:grid-cols-3">
        <div>
          <div className="inline-block rounded-lg bg-white px-3 py-1">
            <Brand />
          </div>
          <p className="mt-3 text-sm">{BUSINESS.tagline}.</p>
          <p className="mt-4 text-sm text-brand-200">Social: Facebook · Instagram · WhatsApp (coming soon)</p>
        </div>

        <div>
          <h3 className="mb-3 font-semibold text-white">Quick links</h3>
          <ul className="space-y-2 text-sm">
            <li><Link href="/products" className="hover:underline">Products</Link></li>
            <li><Link href="/cart" className="hover:underline">Cart</Link></li>
            <li><Link href="/services" className="hover:underline">Services &amp; Returns</Link></li>
            <li><Link href="/about" className="hover:underline">About us</Link></li>
            <li><Link href="/login" className="hover:underline">Login / Sign up</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="mb-3 font-semibold text-white">Contact us</h3>
          <ul className="space-y-2 text-sm">
            <li>
              📧 <a href={`mailto:${BUSINESS.email}`} className="hover:underline">{BUSINESS.email}</a>
            </li>
            <li>
              📞 <a href={`tel:${BUSINESS.phoneIntl}`} className="hover:underline">{BUSINESS.phone}</a>
            </li>
            <li>
              📍 <a href={BUSINESS.mapsUrl} target="_blank" rel="noopener noreferrer" className="hover:underline">{BUSINESS.address}</a>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10 py-4 text-center text-sm text-brand-200">
        © {new Date().getFullYear()} {BUSINESS.name}. All rights reserved.
      </div>
    </footer>
  );
}
