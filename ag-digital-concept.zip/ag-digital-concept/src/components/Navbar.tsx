"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { useCart } from "./CartProvider";
import { BUSINESS } from "@/lib/business";

export function Brand({ className = "" }: { className?: string }) {
  return (
    <span className={`text-2xl font-extrabold tracking-tight ${className}`}>
      <span className="text-black">AG</span>{" "}
      <span className="text-brand-600">Digital</span>{" "}
      <span className="text-black">Concept</span>
    </span>
  );
}

export default function Navbar({
  loggedIn,
  isAdmin,
}: {
  loggedIn: boolean;
  isAdmin: boolean;
}) {
  const [open, setOpen] = useState(false);
  const router = useRouter();
  const { count } = useCart();

  async function logout() {
    await createClient().auth.signOut();
    setOpen(false);
    router.push("/");
    router.refresh();
  }

  const links = [
    { href: "/", label: "Home" },
    { href: "/products", label: "Products" },
    { href: "/services", label: "Services" },
    { href: "/about", label: "About" },
  ];

  return (
    <header>
      <div className="border-b border-brand-100 bg-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <Link href="/" aria-label={`${BUSINESS.name} home`}>
            <Brand />
          </Link>
          <a
            href={`tel:${BUSINESS.phoneIntl}`}
            className="hidden text-sm font-medium text-brand-700 sm:block"
          >
            Call us: {BUSINESS.phone}
          </a>
        </div>
      </div>

      <nav className="bg-nav text-white" aria-label="Main">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4">
          <ul className="hidden items-center gap-1 md:flex">
            {links.map((l) => (
              <li key={l.href}>
                <Link href={l.href} className="block px-3 py-3 font-medium hover:bg-nav-dark">
                  {l.label}
                </Link>
              </li>
            ))}
            {isAdmin && (
              <li>
                <Link href="/admin" className="block px-3 py-3 font-medium hover:bg-nav-dark">
                  Admin
                </Link>
              </li>
            )}
          </ul>

          <button
            className="py-3 font-medium md:hidden"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-label="Toggle menu"
          >
            {open ? "✕ Close" : "☰ Menu"}
          </button>

          <div className="flex items-center gap-1">
            <Link href="/cart" className="relative px-3 py-3 font-medium hover:bg-nav-dark">
              🛒 Cart
              {count > 0 && (
                <span className="ml-1 rounded-full bg-brand-500 px-2 py-0.5 text-xs font-bold text-white">
                  {count}
                </span>
              )}
            </Link>
            {loggedIn ? (
              <>
                <Link
                  href="/account"
                  className="hidden px-3 py-3 font-medium hover:bg-nav-dark sm:block"
                >
                  Account
                </Link>
                <button onClick={logout} className="px-3 py-3 font-medium hover:bg-nav-dark">
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link href="/login" className="px-3 py-3 font-medium hover:bg-nav-dark">
                  Login
                </Link>
                <Link
                  href="/signup"
                  className="hidden px-3 py-3 font-medium hover:bg-nav-dark sm:block"
                >
                  Sign up
                </Link>
              </>
            )}
          </div>
        </div>

        {open && (
          <ul className="border-t border-white/20 md:hidden">
            {links.map((l) => (
              <li key={l.href}>
                <Link
                  href={l.href}
                  onClick={() => setOpen(false)}
                  className="block px-4 py-3 hover:bg-nav-dark"
                >
                  {l.label}
                </Link>
              </li>
            ))}
            {loggedIn ? (
              <li>
                <Link
                  href="/account"
                  onClick={() => setOpen(false)}
                  className="block px-4 py-3 hover:bg-nav-dark"
                >
                  My account
                </Link>
              </li>
            ) : (
              <li>
                <Link
                  href="/signup"
                  onClick={() => setOpen(false)}
                  className="block px-4 py-3 hover:bg-nav-dark"
                >
                  Sign up
                </Link>
              </li>
            )}
            {isAdmin && (
              <li>
                <Link
                  href="/admin"
                  onClick={() => setOpen(false)}
                  className="block px-4 py-3 hover:bg-nav-dark"
                >
                  Admin
                </Link>
              </li>
            )}
          </ul>
        )}
      </nav>
    </header>
  );
}
