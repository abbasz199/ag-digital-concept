"use client";

import Link from "next/link";
import { useState, useTransition } from "react";
import { useCart } from "@/components/CartProvider";
import { BUSINESS, formatPrice } from "@/lib/business";
import { placeOrder } from "./actions";

export default function CheckoutPage() {
  const { lines, subtotal, clear } = useCart();
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [orderId, setOrderId] = useState<string | null>(null);
  const [method, setMethod] = useState<"pay_on_delivery" | "bank_transfer">("pay_on_delivery");

  if (orderId) {
    return (
      <div className="card mx-auto max-w-lg p-10 text-center">
        <div className="text-5xl">🎉</div>
        <h1 className="mt-4 text-2xl font-bold text-brand-800">Order received!</h1>
        <p className="mt-2 text-gray-700">
          Thank you for shopping with {BUSINESS.name}. Your order reference is{" "}
          <strong>{orderId.slice(0, 8).toUpperCase()}</strong>.
        </p>
        <p className="mt-2 text-gray-700">
          {method === "bank_transfer"
            ? "We will contact you shortly with our bank details to complete your payment."
            : "We will call you to confirm delivery. You pay when your items arrive."}
        </p>
        <Link href="/products" className="btn mt-6">
          Continue shopping
        </Link>
      </div>
    );
  }

  if (lines.length === 0) {
    return (
      <div className="card mx-auto max-w-lg p-10 text-center">
        <h1 className="text-2xl font-bold">Nothing to check out</h1>
        <Link href="/products" className="btn mt-6">
          Browse products
        </Link>
      </div>
    );
  }

  function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    const form = new FormData(e.currentTarget);
    const get = (k: string) => String(form.get(k) ?? "");

    startTransition(async () => {
      const result = await placeOrder({
        items: lines.map((l) => ({ product_id: l.product_id, quantity: l.quantity })),
        full_name: get("full_name"),
        phone: get("phone"),
        email: get("email"),
        address: get("address"),
        city: get("city"),
        notes: get("notes"),
        payment_method: method,
      });
      if (result.ok) {
        setOrderId(result.orderId);
        clear();
      } else {
        setError(result.error);
      }
    });
  }

  return (
    <div>
      <h1 className="text-3xl font-bold text-brand-900">Checkout</h1>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_340px]">
        <form onSubmit={onSubmit} className="card space-y-4 p-6">
          <h2 className="text-lg font-semibold">Delivery details</h2>

          <div className="grid gap-4 sm:grid-cols-2">
            <label className="block">
              <span className="mb-1 block text-sm font-medium">Full name *</span>
              <input name="full_name" required className="input" autoComplete="name" />
            </label>
            <label className="block">
              <span className="mb-1 block text-sm font-medium">Phone number *</span>
              <input name="phone" type="tel" required className="input" autoComplete="tel" />
            </label>
          </div>

          <label className="block">
            <span className="mb-1 block text-sm font-medium">Email (optional)</span>
            <input name="email" type="email" className="input" autoComplete="email" />
          </label>

          <label className="block">
            <span className="mb-1 block text-sm font-medium">Delivery address *</span>
            <textarea name="address" required rows={3} className="input" autoComplete="street-address" />
          </label>

          <label className="block">
            <span className="mb-1 block text-sm font-medium">City / Town *</span>
            <input name="city" required defaultValue="Jos" className="input" />
          </label>

          <label className="block">
            <span className="mb-1 block text-sm font-medium">Order notes (optional)</span>
            <textarea name="notes" rows={2} className="input" />
          </label>

          <fieldset>
            <legend className="mb-2 text-sm font-medium">Payment method</legend>
            <div className="space-y-2">
              <label className="flex items-center gap-2">
                <input
                  type="radio"
                  name="payment"
                  checked={method === "pay_on_delivery"}
                  onChange={() => setMethod("pay_on_delivery")}
                />
                Pay on delivery
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="radio"
                  name="payment"
                  checked={method === "bank_transfer"}
                  onChange={() => setMethod("bank_transfer")}
                />
                Bank transfer
              </label>
            </div>
          </fieldset>

          {error && (
            <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700">
              {error}
            </p>
          )}

          <button className="btn w-full" disabled={pending}>
            {pending ? "Placing order…" : `Place order · ${formatPrice(subtotal)}`}
          </button>
        </form>

        <aside className="card h-fit p-5">
          <h2 className="text-lg font-semibold">Order summary</h2>
          <ul className="mt-3 divide-y divide-gray-100 text-sm">
            {lines.map((l) => (
              <li key={l.product_id} className="flex justify-between gap-3 py-2">
                <span>
                  {l.name} × {l.quantity}
                </span>
                <span className="font-medium">{formatPrice(l.price * l.quantity)}</span>
              </li>
            ))}
          </ul>
          <div className="mt-3 flex justify-between border-t border-gray-200 pt-3 text-lg font-bold">
            <span>Total</span>
            <span>{formatPrice(subtotal)}</span>
          </div>
        </aside>
      </div>
    </div>
  );
}
