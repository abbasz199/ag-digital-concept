"use server";

import { randomUUID } from "node:crypto";
import { createClient } from "@/lib/supabase/server";

export type PlaceOrderInput = {
  items: { product_id: string; quantity: number }[];
  full_name: string;
  phone: string;
  email: string;
  address: string;
  city: string;
  notes: string;
  // Add "paystack" | "flutterwave" here when online payment is integrated.
  payment_method: "pay_on_delivery" | "bank_transfer";
};

export type PlaceOrderResult = { ok: true; orderId: string } | { ok: false; error: string };

export async function placeOrder(input: PlaceOrderInput): Promise<PlaceOrderResult> {
  const full_name = input.full_name?.trim();
  const phone = input.phone?.trim();
  const address = input.address?.trim();
  const city = input.city?.trim();

  if (!full_name || !phone || !address || !city) {
    return { ok: false, error: "Please fill in your name, phone, address and city." };
  }
  if (!["pay_on_delivery", "bank_transfer"].includes(input.payment_method)) {
    return { ok: false, error: "Invalid payment method." };
  }
  if (!Array.isArray(input.items) || input.items.length === 0) {
    return { ok: false, error: "Your cart is empty." };
  }

  // Merge duplicate lines and validate quantities.
  const wanted = new Map<string, number>();
  for (const item of input.items) {
    const qty = Math.floor(Number(item.quantity));
    if (!item.product_id || !Number.isFinite(qty) || qty < 1 || qty > 100) {
      return { ok: false, error: "Invalid item in cart." };
    }
    wanted.set(item.product_id, (wanted.get(item.product_id) ?? 0) + qty);
  }

  try {
    const supabase = await createClient();

    // Prices always come from the database, never from the browser.
    const { data: products, error: productError } = await supabase
      .from("products")
      .select("id, name, price, stock")
      .in("id", Array.from(wanted.keys()));

    if (productError || !products || products.length !== wanted.size) {
      return { ok: false, error: "Some items are no longer available. Please review your cart." };
    }

    let total = 0;
    const orderItems: { name: string; price: number; quantity: number; product_id: string }[] = [];
    for (const p of products) {
      const quantity = wanted.get(p.id)!;
      if (p.stock < quantity) {
        return { ok: false, error: `Only ${p.stock} of "${p.name}" left in stock.` };
      }
      total += Number(p.price) * quantity;
      orderItems.push({ product_id: p.id, name: p.name, price: Number(p.price), quantity });
    }

    const {
      data: { user },
    } = await supabase.auth.getUser();

    // Generate the id here so guests (who cannot read orders back) still get a reference.
    const orderId = randomUUID();

    const { error: orderError } = await supabase.from("orders").insert({
      id: orderId,
      user_id: user?.id ?? null,
      total,
      payment_method: input.payment_method,
      full_name,
      phone,
      email: input.email?.trim() || user?.email || null,
      address,
      city,
      notes: input.notes?.trim() || null,
    });
    if (orderError) return { ok: false, error: "Could not place your order. Please try again." };

    const { error: itemsError } = await supabase
      .from("order_items")
      .insert(orderItems.map((i) => ({ ...i, order_id: orderId })));
    if (itemsError) {
      return {
        ok: false,
        error: "Your order was saved but its items failed to save. Please call us to confirm.",
      };
    }

    return { ok: true, orderId };
  } catch {
    return { ok: false, error: "Something went wrong. Please try again." };
  }
}
