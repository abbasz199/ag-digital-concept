import type { Metadata } from "next";
import Link from "next/link";
import ProductCard from "@/components/ProductCard";
import { getCategories, getProducts } from "@/lib/data";

export const metadata: Metadata = {
  title: "Products",
  description: "Browse computer accessories: keyboards, mice, headsets, chargers, monitors and more.",
};

type SearchParams = Promise<{ q?: string; category?: string; sort?: string }>;

export default async function ProductsPage({ searchParams }: { searchParams: SearchParams }) {
  const { q = "", category = "", sort = "" } = await searchParams;
  const [products, categories] = await Promise.all([
    getProducts({ q, category, sort }),
    getCategories(),
  ]);

  return (
    <div>
      <h1 className="text-3xl font-bold text-brand-900">Products</h1>

      <form method="get" className="card mt-6 grid gap-3 p-4 md:grid-cols-[1fr_200px_200px_auto]">
        <input
          type="search"
          name="q"
          defaultValue={q}
          placeholder="Search products…"
          className="input"
          aria-label="Search products"
        />
        <select name="category" defaultValue={category} className="input" aria-label="Category">
          <option value="">All categories</option>
          {categories.map((c) => (
            <option key={c.id} value={c.slug}>
              {c.name}
            </option>
          ))}
        </select>
        <select name="sort" defaultValue={sort} className="input" aria-label="Sort by">
          <option value="">Newest</option>
          <option value="price_asc">Price: low to high</option>
          <option value="price_desc">Price: high to low</option>
          <option value="name">Name A–Z</option>
        </select>
        <button className="btn">Apply</button>
      </form>

      {(q || category) && (
        <p className="mt-4 text-sm text-gray-600">
          {products.length} result{products.length === 1 ? "" : "s"}.{" "}
          <Link href="/products" className="text-brand-700 underline">
            Clear filters
          </Link>
        </p>
      )}

      {products.length > 0 ? (
        <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      ) : (
        <p className="card mt-6 p-8 text-center text-gray-600">No products found.</p>
      )}
    </div>
  );
}
