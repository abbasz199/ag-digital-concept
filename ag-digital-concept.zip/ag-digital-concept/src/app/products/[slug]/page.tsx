import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import AddToCartButton from "@/components/AddToCartButton";
import { ProductImage } from "@/components/ProductCard";
import { getProductBySlug } from "@/lib/data";
import { BUSINESS, formatPrice } from "@/lib/business";

type Params = Promise<{ slug: string }>;

export async function generateMetadata({ params }: { params: Params }): Promise<Metadata> {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) return { title: "Product not found" };
  return {
    title: product.name,
    description: product.description ?? `${product.name} from ${BUSINESS.name}`,
  };
}

export default async function ProductPage({ params }: { params: Params }) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();

  const inStock = product.stock > 0;

  return (
    <div>
      <nav className="mb-6 text-sm text-gray-600" aria-label="Breadcrumb">
        <Link href="/products" className="hover:underline">
          Products
        </Link>
        {product.categories && (
          <>
            {" / "}
            <Link href={`/products?category=${product.categories.slug}`} className="hover:underline">
              {product.categories.name}
            </Link>
          </>
        )}
      </nav>

      <div className="grid gap-8 md:grid-cols-2">
        <div className="card aspect-square overflow-hidden">
          <ProductImage product={product} />
        </div>

        <div>
          <h1 className="text-3xl font-bold">{product.name}</h1>
          <p className="mt-3 text-3xl font-extrabold text-brand-700">{formatPrice(product.price)}</p>
          <p className={`mt-2 font-medium ${inStock ? "text-brand-700" : "text-red-600"}`}>
            {inStock ? `In stock (${product.stock} available)` : "Out of stock"}
          </p>
          {product.description && (
            <p className="mt-5 leading-relaxed text-gray-700">{product.description}</p>
          )}
          <AddToCartButton product={product} disabled={!inStock} className="mt-8 w-full sm:w-auto" />
          <p className="mt-6 text-sm text-gray-600">
            Questions? Call {BUSINESS.phone} or email {BUSINESS.email}.
          </p>
        </div>
      </div>
    </div>
  );
}
