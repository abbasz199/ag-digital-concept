import Link from "next/link";
import ProductCard from "@/components/ProductCard";
import { getCategories, getFeaturedProducts } from "@/lib/data";
import { BUSINESS } from "@/lib/business";

const CATEGORY_ICONS: Record<string, string> = {
  keyboards: "⌨️",
  mice: "🖱️",
  headsets: "🎧",
  "laptop-bags": "🎒",
  "chargers-cables": "🔌",
  "flash-drives": "💾",
  monitors: "🖥️",
  webcams: "📷",
  routers: "📡",
};

const REASONS = [
  { icon: "✅", title: "Quality products", text: "Carefully selected accessories that last." },
  { icon: "🚚", title: "Delivery in Jos & beyond", text: "Pay on delivery or by bank transfer." },
  { icon: "🔁", title: "Easy returns", text: "Faulty item? We replace or refund it." },
  { icon: "📞", title: "Real support", text: `Call or WhatsApp us on ${BUSINESS.phone}.` },
];

export default async function HomePage() {
  const [featured, categories] = await Promise.all([getFeaturedProducts(8), getCategories()]);

  return (
    <div className="space-y-14">
      <section className="overflow-hidden rounded-2xl bg-gradient-to-br from-brand-700 to-brand-900 px-6 py-14 text-white md:px-12 md:py-20">
        <p className="mb-3 text-sm font-semibold uppercase tracking-widest text-brand-200">
          {BUSINESS.name}
        </p>
        <h1 className="max-w-2xl text-3xl font-extrabold leading-tight md:text-5xl">
          Everything your computer needs, in one place.
        </h1>
        <p className="mt-4 max-w-xl text-lg text-brand-100">
          Keyboards, mice, headsets, chargers, monitors, routers and more, at fair prices in Jos,
          Plateau State.
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link href="/products" className="btn bg-white !text-brand-800 hover:!bg-brand-100">
            Shop now
          </Link>
          <Link href="/services" className="btn-outline !border-white !text-white hover:!bg-white/10">
            Customer service
          </Link>
        </div>
      </section>

      {categories.length > 0 && (
        <section>
          <h2 className="mb-5 text-2xl font-bold text-brand-900">Shop by category</h2>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-5">
            {categories.map((c) => (
              <Link
                key={c.id}
                href={`/products?category=${c.slug}`}
                className="card flex flex-col items-center gap-2 p-4 text-center transition hover:border-brand-500"
              >
                <span className="text-3xl">{CATEGORY_ICONS[c.slug] ?? "💻"}</span>
                <span className="text-sm font-medium">{c.name}</span>
              </Link>
            ))}
          </div>
        </section>
      )}

      <section>
        <div className="mb-5 flex items-end justify-between">
          <h2 className="text-2xl font-bold text-brand-900">Featured products</h2>
          <Link href="/products" className="font-medium text-brand-700 hover:underline">
            View all →
          </Link>
        </div>
        {featured.length > 0 ? (
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {featured.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        ) : (
          <p className="card p-6 text-gray-600">
            Products will appear here once the database is connected and seeded.
          </p>
        )}
      </section>

      <section>
        <h2 className="mb-5 text-2xl font-bold text-brand-900">Why choose {BUSINESS.name}?</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {REASONS.map((r) => (
            <div key={r.title} className="card p-5">
              <div className="text-3xl">{r.icon}</div>
              <h3 className="mt-2 font-semibold">{r.title}</h3>
              <p className="mt-1 text-sm text-gray-600">{r.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="rounded-2xl bg-brand-100 p-8 text-center">
        <h2 className="text-2xl font-bold text-brand-900">Need help choosing?</h2>
        <p className="mx-auto mt-2 max-w-xl text-gray-700">
          Visit us at {BUSINESS.address} or call {BUSINESS.phone}.
        </p>
        <Link href="/about" className="btn mt-5">
          Contact &amp; location
        </Link>
      </section>
    </div>
  );
}
