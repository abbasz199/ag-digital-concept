import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { getUserAndRole } from "@/lib/supabase/server";
import { formatPrice } from "@/lib/business";
import type { Order } from "@/lib/types";

export const metadata: Metadata = { title: "My account" };

export default async function AccountPage() {
  const { supabase, user, isAdmin } = await getUserAndRole();
  if (!user) redirect("/login?next=/account");

  const [{ data: profile }, { data: orders }] = await Promise.all([
    supabase.from("profiles").select("full_name, phone").eq("id", user.id).maybeSingle(),
    supabase
      .from("orders")
      .select("id, created_at, status, total, payment_method, full_name, phone, address, city")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false }),
  ]);

  const list = (orders ?? []) as Order[];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-brand-900">My account</h1>
        <p className="mt-2 text-gray-700">
          {profile?.full_name ?? "Customer"} · {user.email}
          {profile?.phone ? ` · ${profile.phone}` : ""}
        </p>
        {isAdmin && (
          <Link href="/admin" className="btn mt-4">
            Open admin dashboard
          </Link>
        )}
      </div>

      <section>
        <h2 className="mb-4 text-xl font-semibold">Order history</h2>
        {list.length === 0 ? (
          <p className="card p-6 text-gray-600">
            You have no orders yet.{" "}
            <Link href="/products" className="text-brand-700 underline">
              Start shopping
            </Link>
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="card w-full min-w-[560px] text-left text-sm">
              <thead className="bg-brand-100 text-brand-900">
                <tr>
                  <th className="p-3">Ref</th>
                  <th className="p-3">Date</th>
                  <th className="p-3">Payment</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 text-right">Total</th>
                </tr>
              </thead>
              <tbody>
                {list.map((o) => (
                  <tr key={o.id} className="border-t border-gray-100">
                    <td className="p-3 font-mono">{o.id.slice(0, 8).toUpperCase()}</td>
                    <td className="p-3">{new Date(o.created_at).toLocaleDateString("en-NG")}</td>
                    <td className="p-3 capitalize">{o.payment_method.replace(/_/g, " ")}</td>
                    <td className="p-3 capitalize">{o.status}</td>
                    <td className="p-3 text-right font-semibold">{formatPrice(o.total)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
