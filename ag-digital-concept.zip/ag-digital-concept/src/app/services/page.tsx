import type { Metadata } from "next";
import { BUSINESS } from "@/lib/business";
import FeedbackForm from "./FeedbackForm";

export const metadata: Metadata = {
  title: "Customer Service",
  description: "Contact AG Digital Concept, send feedback and read our returns and refund policy.",
};

export default function ServicesPage() {
  return (
    <div className="space-y-10">
      <header>
        <h1 className="text-3xl font-bold text-brand-900">Customer service</h1>
        <p className="mt-2 max-w-2xl text-gray-700">
          We are here to help with orders, product questions, returns and feedback.
        </p>
      </header>

      <section className="grid gap-4 sm:grid-cols-3">
        <a href={`tel:${BUSINESS.phoneIntl}`} className="card p-5 hover:border-brand-500">
          <div className="text-3xl">📞</div>
          <h2 className="mt-2 font-semibold">Call us</h2>
          <p className="text-brand-700">{BUSINESS.phone}</p>
        </a>
        <a href={`mailto:${BUSINESS.email}`} className="card p-5 hover:border-brand-500">
          <div className="text-3xl">📧</div>
          <h2 className="mt-2 font-semibold">Email us</h2>
          <p className="break-all text-brand-700">{BUSINESS.email}</p>
        </a>
        <a
          href={BUSINESS.mapsUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="card p-5 hover:border-brand-500"
        >
          <div className="text-3xl">📍</div>
          <h2 className="mt-2 font-semibold">Visit us</h2>
          <p className="text-brand-700">{BUSINESS.address}</p>
        </a>
      </section>

      <section className="card p-6">
        <h2 className="text-xl font-semibold text-brand-900">Send us feedback</h2>
        <p className="mb-5 mt-1 text-sm text-gray-600">Tell us what we are doing well and what we can improve.</p>
        <FeedbackForm />
      </section>

      <section className="card p-6" id="returns">
        <h2 className="text-xl font-semibold text-brand-900">Returns &amp; refund policy</h2>
        <ul className="mt-4 list-disc space-y-2 pl-5 text-gray-700">
          <li>Report a faulty, damaged or wrong item within 3 days of delivery.</li>
          <li>Items must be unused, in original packaging, with all accessories included.</li>
          <li>Approved returns are replaced or refunded, whichever you prefer, subject to stock.</li>
          <li>Items damaged through misuse, liquid or tampering are not eligible.</li>
          <li>
            To start a return, call {BUSINESS.phone} or email {BUSINESS.email} with your order
            reference.
          </li>
        </ul>
        <p className="mt-4 text-xs text-gray-500">
          Edit this policy to match your actual business terms before launch.
        </p>
      </section>
    </div>
  );
}
