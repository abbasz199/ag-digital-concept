"use server";

import { createClient } from "@/lib/supabase/server";

export type FeedbackResult = { ok: true } | { ok: false; error: string };

export async function submitFeedback(input: {
  name: string;
  email: string;
  message: string;
}): Promise<FeedbackResult> {
  const name = input.name?.trim();
  const email = input.email?.trim();
  const message = input.message?.trim();

  if (!name || !email || !message) return { ok: false, error: "Please fill in every field." };
  if (!/^\S+@\S+\.\S+$/.test(email)) return { ok: false, error: "Please enter a valid email." };
  if (message.length > 2000) return { ok: false, error: "Message is too long (max 2000 characters)." };

  try {
    const supabase = await createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    const { error } = await supabase
      .from("feedback")
      .insert({ user_id: user?.id ?? null, name, email, message });
    if (error) return { ok: false, error: "Could not send your feedback. Please try again." };
    return { ok: true };
  } catch {
    return { ok: false, error: "Something went wrong. Please try again." };
  }
}
