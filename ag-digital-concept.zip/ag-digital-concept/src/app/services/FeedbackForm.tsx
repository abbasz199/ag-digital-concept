"use client";

import { useState, useTransition } from "react";
import { submitFeedback } from "./actions";

export default function FeedbackForm() {
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [sent, setSent] = useState(false);

  function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const formEl = e.currentTarget;
    const form = new FormData(formEl);
    setError(null);

    startTransition(async () => {
      const result = await submitFeedback({
        name: String(form.get("name") ?? ""),
        email: String(form.get("email") ?? ""),
        message: String(form.get("message") ?? ""),
      });
      if (result.ok) {
        setSent(true);
        formEl.reset();
      } else {
        setError(result.error);
      }
    });
  }

  if (sent) {
    return (
      <p role="status" className="rounded-lg bg-brand-100 p-4 text-brand-800">
        Thank you! Your feedback has been sent.
      </p>
    );
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="block">
          <span className="mb-1 block text-sm font-medium">Your name</span>
          <input name="name" required className="input" autoComplete="name" />
        </label>
        <label className="block">
          <span className="mb-1 block text-sm font-medium">Email</span>
          <input name="email" type="email" required className="input" autoComplete="email" />
        </label>
      </div>
      <label className="block">
        <span className="mb-1 block text-sm font-medium">Message</span>
        <textarea name="message" required rows={4} maxLength={2000} className="input" />
      </label>
      {error && (
        <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700">
          {error}
        </p>
      )}
      <button className="btn" disabled={pending}>
        {pending ? "Sending…" : "Send feedback"}
      </button>
    </form>
  );
}
