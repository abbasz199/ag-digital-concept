"use client";

import Link from "next/link";
import { useCart } from "@/components/CartProvider";
import { formatPrice } from "@/lib/business";

export default function CartPage() {
  const { lines, subtotal, setQuantity, remove, clear } = useCart();

  if (lines.length === 0) {
    return (
      <div className="card mx-auto max-w-lg p-10 text-center">
        <div className="text-5xl">🛒</div>
        <h1 className="mt-4 text-2xl font-bold">Your cart is empty</h1>
        <p className="mt-2 text-gray-600">Add some accessories to get started.</p>
        <Link href="/products" className="btn mt-6">
          Browse products
        </Link>
      </div>
    );
  }

  return (
    <div>
      <h1 className="text-3xl font-bold text-brand-900">Your cart</h1>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_320px]">
        <ul className="space-y-3">
          {lines.map((l) => (
            <li key={l.product_id} className="card flex items-center gap-4 p-4">
              <div className="h-20 w-20 shrink-0 overflow-hidden rounded-lg bg-brand-100">
                {l.image_url ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={l.image_url} alt={l.name} className="h-full w-full object-cover" />
                ) : (
                  <div className="flex h-full items-center justify-center text-3xl">🖱️</div>
                )}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-semibold">{l.name}</p>
                <p className="text-brand-700">{formatPrice(l.price)}</p>
                <div className="mt-2 flex items-center gap-2">
                  <button
                    className="h-8 w-8 rounded border border-gray-300 hover:bg-brand-100"
                    onClick={() => setQuantity(l.product_id, l.quantity - 1)}
                    aria-label={`Decrease quantity of ${l.name}`}
                  >
                    −
                  </button>
                  <span className="w-8 text-center" aria-live="polite">
                    {l.quantity}
                  </span>
                  <button
                    className="h-8 w-8 rounded border border-gray-300 hover:bg-brand-100"
                    onClick={() => setQuantity(l.product_id, l.quantity + 1)}
                    aria-label={`Increase quantity of ${l.name}`}
                  >
                    +
                  </button>
                  <button
                    className="ml-3 text-sm text-red-600 hover:underline"
                    onClick={() => remove(l.product_id)}
                  >
                    Remove
                  </button>
                </div>
              </div>
              <p className="hidden font-bold sm:block">{formatPrice(l.price * l.quantity)}</p>
            </li>
          ))}
        </ul>

        <aside className="card h-fit p-5">
          <h2 className="text-lg font-semibold">Order summary</h2>
          <div className="mt-4 flex justify-between text-lg">
            <span>Subtotal</span>
            <span className="font-bold">{formatPrice(subtotal)}</span>
          </div>
          <p className="mt-1 text-xs text-gray-500">Delivery fee, if any, is confirmed by phone.</p>
          <Link href="/checkout" className="btn mt-5 w-full">
            Proceed to checkout
          </Link>
          <button onClick={clear} className="mt-3 w-full text-sm text-gray-600 hover:underline">
            Clear cart
          </button>
        </aside>
      </div>
    </div>
  );
}
