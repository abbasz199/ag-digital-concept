"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function SignupPage() {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setNotice(null);
    setLoading(true);
    const form = new FormData(e.currentTarget);

    const { data, error } = await createClient().auth.signUp({
      email: String(form.get("email")),
      password: String(form.get("password")),
      options: {
        data: {
          full_name: String(form.get("full_name")),
          phone: String(form.get("phone")),
        },
        emailRedirectTo: `${window.location.origin}/account`,
      },
    });
    setLoading(false);

    if (error) {
      setError(error.message);
      return;
    }

    if (data.session) {
      router.push("/account");
      router.refresh();
    } else {
      setNotice("Account created! Check your email to confirm your address, then log in.");
    }
  }

  return (
    <div className="card mx-auto max-w-md p-8">
      <h1 className="text-2xl font-bold text-brand-900">Create your account</h1>
      <p className="mt-1 text-gray-600">Track orders and keep your cart across devices.</p>

      <form onSubmit={onSubmit} className="mt-6 space-y-4">
        <label className="block">
          <span className="mb-1 block text-sm font-medium">Full name</span>
          <input name="full_name" required autoComplete="name" className="input" />
        </label>
        <label className="block">
          <span className="mb-1 block text-sm font-medium">Phone number</span>
          <input name="phone" type="tel" required autoComplete="tel" className="input" />
        </label>
        <label className="block">
          <span className="mb-1 block text-sm font-medium">Email</span>
          <input name="email" type="email" required autoComplete="email" className="input" />
        </label>
        <label className="block">
          <span className="mb-1 block text-sm font-medium">Password (min. 6 characters)</span>
          <input
            name="password"
            type="password"
            required
            minLength={6}
            autoComplete="new-password"
            className="input"
          />
        </label>
        {error && (
          <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700">
            {error}
          </p>
        )}
        {notice && (
          <p role="status" className="rounded-lg bg-brand-100 p-3 text-sm text-brand-800">
            {notice}
          </p>
        )}
        <button className="btn w-full" disabled={loading}>
          {loading ? "Creating account…" : "Sign up"}
        </button>
      </form>

      <p className="mt-5 text-center text-sm text-gray-600">
        Already have an account?{" "}
        <Link href="/login" className="font-medium text-brand-700 underline">
          Log in
        </Link>
      </p>
    </div>
  );
}
