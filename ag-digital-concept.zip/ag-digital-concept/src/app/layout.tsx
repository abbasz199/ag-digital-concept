import type { Metadata, Viewport } from "next";
import "./globals.css";
import { CartProvider } from "@/components/CartProvider";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { getUserAndRole } from "@/lib/supabase/server";
import { BUSINESS } from "@/lib/business";

export const metadata: Metadata = {
  title: {
    default: `${BUSINESS.name} | Computer Accessories in Jos, Plateau State`,
    template: `%s | ${BUSINESS.name}`,
  },
  description:
    "Buy keyboards, mice, headsets, chargers, monitors, routers and more computer accessories from AG Digital Concept in Jos, Plateau State.",
  keywords: ["computer accessories", "Jos", "Plateau State", "keyboards", "laptop bags", "AG Digital Concept"],
  openGraph: {
    title: BUSINESS.name,
    description: BUSINESS.tagline,
    type: "website",
    locale: "en_NG",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#16a34a",
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const { user, isAdmin } = await getUserAndRole();

  return (
    <html lang="en">
      <body className="flex min-h-screen flex-col">
        <CartProvider>
          <Navbar loggedIn={Boolean(user)} isAdmin={isAdmin} />
          <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8">{children}</main>
          <Footer />
        </CartProvider>
      </body>
    </html>
  );
}
