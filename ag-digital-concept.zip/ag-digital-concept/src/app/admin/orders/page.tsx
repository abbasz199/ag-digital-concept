import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { getUserAndRole } from "@/lib/supabase/server";
import { formatPrice } from "@/lib/business";
import { updateOrderStatus } from "../actions";

export const metadata: Metadata = { title: "Admin: Orders" };

type SearchParams = Promise<{ error?: string; saved?: string }>;

type OrderRow = {
  id: string;
  created_at: string;
  status: string;
  total: number;
  payment_method: string;
  full_name: string;
  phone: string;
  address: string;
  city: string;
  notes: string | null;
  order_items: { name: string; quantity: number; price: number }[];
};

const STATUSES = ["pending", "confirmed", "shipped", "delivered", "cancelled"];

export default async function AdminOrdersPage({ searchParams }: { searchParams: SearchParams }) {
  const { error, saved } = await searchParams;
  const { supabase, user, isAdmin } = await getUserAndRole();
  if (!user) redirect("/login?next=/admin/orders");
  if (!isAdmin) redirect("/admin");

  const { data } = await supabase
    .from("orders")
    .select("*, order_items(name, quantity, price)")
    .order("created_at", { ascending: false });
  const orders = (data ?? []) as unknown as OrderRow[];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-3xl font-bold text-brand-900">Orders</h1>
        <nav className="flex gap-2">
          <Link href="/admin" className="btn-outline">Products</Link>
          <Link href="/admin/orders" className="btn">Orders</Link>
        </nav>
      </div>

      {error && <p role="alert" className="rounded-lg bg-red-50 p-3 text-red-700">{error}</p>}
      {saved && <p role="status" className="rounded-lg bg-brand-100 p-3 text-brand-800">Order updated.</p>}

      {orders.length === 0 ? (
        <p className="card p-6 text-gray-600">No orders yet.</p>
      ) : (
        <ul className="space-y-4">
          {orders.map((o) => (
            <li key={o.id} className="card p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="font-mono text-sm text-gray-500">
                    #{o.id.slice(0, 8).toUpperCase()} · {new Date(o.created_at).toLocaleString("en-NG")}
                  </p>
                  <p className="mt-1 font-semibold">{o.full_name}</p>
                  <p className="text-sm text-gray-700">
                    <a href={`tel:${o.phone}`} className="text-brand-700 hover:underline">{o.phone}</a>
                    {" · "}
                    {o.address}, {o.city}
                  </p>
                  {o.notes && <p className="mt-1 text-sm italic text-gray-600">Note: {o.notes}</p>}
                </div>
                <div className="text-right">
                  <p className="text-xl font-bold text-brand-800">{formatPrice(o.total)}</p>
                  <p className="text-sm capitalize text-gray-600">{o.payment_method.replace(/_/g, " ")}</p>
                </div>
              </div>

              <ul className="mt-3 text-sm text-gray-700">
                {o.order_items.map((i, idx) => (
                  <li key={idx}>
                    {i.quantity} × {i.name} ({formatPrice(i.price)})
                  </li>
                ))}
              </ul>

              <form action={updateOrderStatus.bind(null, o.id)} className="mt-4 flex items-center gap-2">
                <select name="status" defaultValue={o.status} className="input max-w-[180px]" aria-label="Order status">
                  {STATUSES.map((s) => (
                    <option key={s} value={s}>
                      {s.charAt(0).toUpperCase() + s.slice(1)}
                    </option>
                  ))}
                </select>
                <button className="btn !py-2">Update</button>
              </form>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
