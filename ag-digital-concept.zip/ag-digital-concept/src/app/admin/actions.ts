"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { getUserAndRole } from "@/lib/supabase/server";

const ORDER_STATUSES = ["pending", "confirmed", "shipped", "delivered", "cancelled"];

function slugify(text: string) {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

async function requireAdmin() {
  const ctx = await getUserAndRole();
  if (!ctx.user || !ctx.isAdmin) redirect("/login?next=/admin");
  return ctx.supabase;
}

async function uploadImage(
  supabase: Awaited<ReturnType<typeof requireAdmin>>,
  file: File | null
): Promise<string | null> {
  if (!file || file.size === 0) return null;
  if (!file.type.startsWith("image/")) throw new Error("Only image files are allowed.");
  if (file.size > 5 * 1024 * 1024) throw new Error("Image must be smaller than 5MB.");

  const ext = (file.name.split(".").pop() || "jpg").toLowerCase().replace(/[^a-z0-9]/g, "");
  const path = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const { error } = await supabase.storage
    .from("product-images")
    .upload(path, file, { contentType: file.type, upsert: false });
  if (error) throw new Error("Image upload failed.");

  return supabase.storage.from("product-images").getPublicUrl(path).data.publicUrl;
}

function readFields(formData: FormData) {
  const name = String(formData.get("name") ?? "").trim();
  const price = Number(formData.get("price"));
  const stock = Math.floor(Number(formData.get("stock")));
  if (!name) throw new Error("Name is required.");
  if (!Number.isFinite(price) || price < 0) throw new Error("Enter a valid price.");
  if (!Number.isFinite(stock) || stock < 0) throw new Error("Enter a valid stock number.");
  return {
    name,
    price,
    stock,
    description: String(formData.get("description") ?? "").trim() || null,
    category_id: String(formData.get("category_id") ?? "") || null,
    featured: formData.get("featured") === "on",
  };
}

function fail(path: string, message: string): never {
  redirect(`${path}?error=${encodeURIComponent(message)}`);
}

export async function createProduct(formData: FormData) {
  const supabase = await requireAdmin();
  let message: string | null = null;

  try {
    const fields = readFields(formData);
    const image_url = await uploadImage(supabase, formData.get("image") as File | null);
    const slug = `${slugify(fields.name)}-${Math.random().toString(36).slice(2, 6)}`;
    const { error } = await supabase.from("products").insert({ ...fields, slug, image_url });
    if (error) message = "Could not save the product.";
  } catch (e) {
    message = e instanceof Error ? e.message : "Something went wrong.";
  }

  if (message) fail("/admin", message);
  revalidatePath("/", "layout");
  redirect("/admin?saved=1");
}

export async function updateProduct(id: string, formData: FormData) {
  const supabase = await requireAdmin();
  let message: string | null = null;

  try {
    const fields = readFields(formData);
    const newImage = await uploadImage(supabase, formData.get("image") as File | null);
    const update = newImage ? { ...fields, image_url: newImage } : fields;
    const { error } = await supabase.from("products").update(update).eq("id", id);
    if (error) message = "Could not update the product.";
  } catch (e) {
    message = e instanceof Error ? e.message : "Something went wrong.";
  }

  if (message) fail(`/admin/products/${id}`, message);
  revalidatePath("/", "layout");
  redirect("/admin?saved=1");
}

export async function deleteProduct(id: string) {
  const supabase = await requireAdmin();
  const { error } = await supabase.from("products").delete().eq("id", id);
  if (error) fail("/admin", "Could not delete the product.");
  revalidatePath("/", "layout");
  redirect("/admin?saved=1");
}

export async function updateOrderStatus(id: string, formData: FormData) {
  const supabase = await requireAdmin();
  const status = String(formData.get("status") ?? "");
  if (!ORDER_STATUSES.includes(status)) fail("/admin/orders", "Invalid status.");

  const { error } = await supabase.from("orders").update({ status }).eq("id", id);
  if (error) fail("/admin/orders", "Could not update the order.");
  revalidatePath("/admin/orders");
  redirect("/admin/orders?saved=1");
}
