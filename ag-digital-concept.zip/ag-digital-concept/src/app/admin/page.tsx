import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import ProductForm from "@/components/ProductForm";
import { getUserAndRole } from "@/lib/supabase/server";
import { formatPrice } from "@/lib/business";
import type { Category, Product } from "@/lib/types";
import { createProduct, deleteProduct } from "./actions";

export const metadata: Metadata = { title: "Admin: Products" };

type SearchParams = Promise<{ error?: string; saved?: string }>;

export default async function AdminPage({ searchParams }: { searchParams: SearchParams }) {
  const { error, saved } = await searchParams;
  const { supabase, user, isAdmin } = await getUserAndRole();
  if (!user) redirect("/login?next=/admin");

  if (!isAdmin) {
    return (
      <div className="card mx-auto max-w-lg p-8 text-center">
        <h1 className="text-2xl font-bold">Admins only</h1>
        <p className="mt-2 text-gray-600">Your account does not have admin access.</p>
      </div>
    );
  }

  const [{ data: products }, { data: categories }] = await Promise.all([
    supabase.from("products").select("*, categories(name, slug)").order("created_at", { ascending: false }),
    supabase.from("categories").select("*").order("name"),
  ]);
  const list = (products ?? []) as unknown as Product[];

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-3xl font-bold text-brand-900">Admin dashboard</h1>
        <nav className="flex gap-2">
          <Link href="/admin" className="btn">Products</Link>
          <Link href="/admin/orders" className="btn-outline">Orders</Link>
        </nav>
      </div>

      {error && <p role="alert" className="rounded-lg bg-red-50 p-3 text-red-700">{error}</p>}
      {saved && <p role="status" className="rounded-lg bg-brand-100 p-3 text-brand-800">Saved.</p>}

      <section className="card p-6">
        <h2 className="mb-4 text-xl font-semibold">Add a product</h2>
        <ProductForm
          action={createProduct}
          categories={(categories ?? []) as Category[]}
          submitLabel="Add product"
        />
      </section>

      <section>
        <h2 className="mb-4 text-xl font-semibold">All products ({list.length})</h2>
        <div className="overflow-x-auto">
          <table className="card w-full min-w-[640px] text-left text-sm">
            <thead className="bg-brand-100 text-brand-900">
              <tr>
                <th className="p-3">Name</th>
                <th className="p-3">Category</th>
                <th className="p-3 text-right">Price</th>
                <th className="p-3 text-right">Stock</th>
                <th className="p-3">Featured</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {list.map((p) => (
                <tr key={p.id} className="border-t border-gray-100">
                  <td className="p-3 font-medium">{p.name}</td>
                  <td className="p-3">{p.categories?.name ?? "-"}</td>
                  <td className="p-3 text-right">{formatPrice(p.price)}</td>
                  <td className="p-3 text-right">{p.stock}</td>
                  <td className="p-3">{p.featured ? "Yes" : "No"}</td>
                  <td className="p-3">
                    <div className="flex justify-end gap-3">
                      <Link href={`/admin/products/${p.id}`} className="text-brand-700 hover:underline">
                        Edit
                      </Link>
                      <form action={deleteProduct.bind(null, p.id)}>
                        <button className="text-red-600 hover:underline">Delete</button>
                      </form>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
