import type { Metadata } from "next";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import ProductForm from "@/components/ProductForm";
import { getUserAndRole } from "@/lib/supabase/server";
import type { Category, Product } from "@/lib/types";
import { updateProduct } from "../../actions";

export const metadata: Metadata = { title: "Admin: Edit product" };

type Params = Promise<{ id: string }>;
type SearchParams = Promise<{ error?: string }>;

export default async function EditProductPage({
  params,
  searchParams,
}: {
  params: Params;
  searchParams: SearchParams;
}) {
  const { id } = await params;
  const { error } = await searchParams;
  const { supabase, user, isAdmin } = await getUserAndRole();
  if (!user) redirect(`/login?next=/admin/products/${id}`);
  if (!isAdmin) redirect("/admin");

  const [{ data: product }, { data: categories }] = await Promise.all([
    supabase.from("products").select("*").eq("id", id).maybeSingle(),
    supabase.from("categories").select("*").order("name"),
  ]);
  if (!product) notFound();

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <Link href="/admin" className="text-sm text-brand-700 hover:underline">
        ← Back to products
      </Link>
      <h1 className="text-3xl font-bold text-brand-900">Edit product</h1>
      {error && <p role="alert" className="rounded-lg bg-red-50 p-3 text-red-700">{error}</p>}
      <div className="card p-6">
        <ProductForm
          action={updateProduct.bind(null, id)}
          categories={(categories ?? []) as Category[]}
          product={product as Product}
          submitLabel="Save changes"
        />
      </div>
    </div>
  );
}
