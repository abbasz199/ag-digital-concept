import type { Metadata } from "next";
import { BUSINESS } from "@/lib/business";

export const metadata: Metadata = {
  title: "About Us",
  description: "About AG Digital Concept, a computer accessories store in Dadin Kowa, Jos South, Plateau State.",
};

export default function AboutPage() {
  return (
    <div className="space-y-10">
      <header>
        <h1 className="text-3xl font-bold text-brand-900">About {BUSINESS.name}</h1>
        <p className="mt-3 max-w-2xl text-lg text-gray-700">
          {BUSINESS.name} supplies reliable computer accessories to students, professionals,
          gamers and businesses in Jos and across Plateau State. {BUSINESS.tagline}.
        </p>
      </header>

      <section className="grid gap-6 md:grid-cols-2">
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-brand-900">Our story</h2>
          <p className="mt-3 leading-relaxed text-gray-700">
            We started with a simple goal: make good computer accessories easy to find and fairly
            priced. From keyboards and mice to chargers, monitors and routers, every item we sell
            is chosen for quality and value.
          </p>
          <p className="mt-3 text-xs text-gray-500">
            Replace this text with your own story and add the owner&apos;s name before launch.
          </p>
        </div>

        <div className="card p-6">
          <h2 className="text-xl font-semibold text-brand-900">Business details</h2>
          <dl className="mt-3 space-y-3 text-gray-700">
            <div>
              <dt className="text-sm font-medium text-gray-500">Business name</dt>
              <dd>{BUSINESS.name}</dd>
            </div>
            <div>
              <dt className="text-sm font-medium text-gray-500">Email</dt>
              <dd>
                <a href={`mailto:${BUSINESS.email}`} className="text-brand-700 hover:underline">
                  {BUSINESS.email}
                </a>
              </dd>
            </div>
            <div>
              <dt className="text-sm font-medium text-gray-500">Phone</dt>
              <dd>
                <a href={`tel:${BUSINESS.phoneIntl}`} className="text-brand-700 hover:underline">
                  {BUSINESS.phone}
                </a>
              </dd>
            </div>
            <div>
              <dt className="text-sm font-medium text-gray-500">Address</dt>
              <dd>
                {BUSINESS.address}{" "}
                <a
                  href={BUSINESS.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="whitespace-nowrap text-brand-700 hover:underline"
                >
                  View on Google Maps ↗
                </a>
              </dd>
            </div>
          </dl>
        </div>
      </section>
    </div>
  );
}
