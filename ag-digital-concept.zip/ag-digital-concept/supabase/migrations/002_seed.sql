-- Sample data: categories and 12 computer accessories (prices in Naira)

insert into public.categories (name, slug) values
  ('Keyboards', 'keyboards'),
  ('Mice', 'mice'),
  ('Headsets', 'headsets'),
  ('Laptop Bags', 'laptop-bags'),
  ('Chargers & Cables', 'chargers-cables'),
  ('Flash Drives', 'flash-drives'),
  ('Monitors', 'monitors'),
  ('Webcams', 'webcams'),
  ('Routers', 'routers')
on conflict (slug) do nothing;

insert into public.products (name, slug, description, price, stock, featured, category_id)
select p.name, p.slug, p.description, p.price, p.stock, p.featured, c.id
from (values
  ('Wireless Keyboard & Mouse Combo', 'wireless-keyboard-mouse-combo', 'Slim 2.4GHz wireless keyboard and mouse set with USB receiver.', 18500, 25, true, 'keyboards'),
  ('Mechanical Gaming Keyboard', 'mechanical-gaming-keyboard', 'RGB backlit mechanical keyboard with blue switches.', 32000, 12, true, 'keyboards'),
  ('Ergonomic Wireless Mouse', 'ergonomic-wireless-mouse', 'Comfortable 1600 DPI wireless mouse with silent clicks.', 7500, 40, false, 'mice'),
  ('Gaming Mouse 7200 DPI', 'gaming-mouse-7200-dpi', 'Wired gaming mouse with adjustable DPI and RGB lighting.', 12000, 20, true, 'mice'),
  ('Over-Ear Headset with Mic', 'over-ear-headset-with-mic', 'Padded headset with noise-cancelling microphone for calls and gaming.', 15000, 18, true, 'headsets'),
  ('15.6" Laptop Backpack', 'laptop-backpack-15-6', 'Water-resistant backpack with padded laptop compartment and USB port.', 21000, 15, false, 'laptop-bags'),
  ('65W USB-C Laptop Charger', 'usb-c-laptop-charger-65w', 'Fast GaN USB-C charger compatible with most modern laptops.', 16500, 30, true, 'chargers-cables'),
  ('USB-C to USB-C Cable 2m', 'usb-c-cable-2m', 'Durable braided cable supporting fast charging and data transfer.', 3500, 60, false, 'chargers-cables'),
  ('64GB USB 3.0 Flash Drive', 'flash-drive-64gb-usb3', 'High-speed 64GB flash drive with metal casing.', 6500, 50, false, 'flash-drives'),
  ('24" Full HD Monitor', 'monitor-24-full-hd', '24-inch IPS Full HD monitor with HDMI and VGA inputs.', 95000, 8, true, 'monitors'),
  ('1080p HD Webcam', 'hd-webcam-1080p', 'Full HD webcam with built-in microphone and auto light correction.', 14000, 22, false, 'webcams'),
  ('Dual-Band Wi-Fi Router', 'dual-band-wifi-router', 'AC1200 dual-band router with four antennas for strong coverage.', 24000, 14, false, 'routers')
) as p(name, slug, description, price, stock, featured, cat_slug)
join public.categories c on c.slug = p.cat_slug
on conflict (slug) do nothing;

-- After you sign up on the website, make yourself admin (replace the email):
-- update public.profiles set role = 'admin'
-- where id = (select id from auth.users where email = 'garbadeen199@gmail.com');
